# freeNime
this project was build using the [consumet-api](https://github.com/consumet/api.consumet.org) 

## ScreenShots
### main page
![image](https://github.com/user-attachments/assets/d756ae56-f490-4703-9631-1ecb9870c2f0)
### watch page
![image](https://github.com/user-attachments/assets/f3de74ae-5936-4ee1-94a9-733138984d0e)
### anime info
![image](https://github.com/user-attachments/assets/835f07a6-512f-436f-bd52-1b66a9da40fe)
![image](https://github.com/user-attachments/assets/de68d5fb-dde2-4d5c-a471-e7fb785851ad)

### WebSite
[Check the site](https://freenime.netlify.app/ "freeNime")

## ToDo
- Add user authentication
- Filter and order episodes
- Add toWatch list
- Rebuild with next ✔️
- Fix bugs in anime info page

### Contact
feel free to contact me
leandroGonzalezMat@gmail.com
