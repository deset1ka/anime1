export const metadata = {
  title: "Airing Schedule - FreeNime",
  description: "Weekly Airing Schedule",
};

export default function AiringScheduleLayout({ children }) {
  return <>{children}</>;
}
