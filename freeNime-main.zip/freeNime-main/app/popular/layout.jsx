export const metadata = {
  title: "Popular Anime - FreeNime",
  description: "Most popular anime currently",
};

export default function AiringScheduleLayout({ children }) {
  return <>{children}</>;
}
