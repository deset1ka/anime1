export const metadata = {
  title: "Results - FreeNime",
  description: "Results for your search",
};


export default function AiringScheduleLayout({ children }) {
  return <>{children}</>;
}
